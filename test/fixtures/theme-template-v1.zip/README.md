# Origo X Theme Template v1

Change id, name, description, author and version before submitting your own theme.
Every id belongs to its first accepted submitting account; never reuse the sample id.
All example images in this template may be used and modified under Apache-2.0.
Retain LICENSE.txt and these notices when using the sample artwork.

Icon geometry: Copyright 2019-present Bytedance Inc., IconPark v1.4.2,
https://github.com/bytedance/IconPark/tree/v1.4.2
Modified by Origo X: three-color composition, badges, light/dark and selected states.
Original background compositions and template: Copyright 2026 Origo X contributors.

PNG/JPEG/WebP static images only. No scripts, fonts, SVG or remote references.
Icons: transparent square PNG/WebP up to 512 px. Preview: assets/preview.png,
up to 1600 px. Other artwork up to 2048 px. Total decoded pixels <=24 million.
ZIP <=10 MiB; expanded bytes <=20 MiB; <=96 entries; manifest <=64 KiB.
Place manifest.json, LICENSE.txt, README.md and assets/ directly at ZIP root.
Unreferenced images, duplicate paths and encrypted/symlink entries are forbidden.
Omitted slots use the original app glyph; glass and reading preferences stay independent.
The website decodes/re-encodes images and publishes a canonical ZIP after review.
